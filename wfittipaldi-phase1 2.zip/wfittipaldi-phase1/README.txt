Will Fittipaldi
John Rodkey, Jaron Burdick, group members.
https://github.com/trvrenglish/CS-125
We have a shared repository that holds all of our readme files, erdplus file, and the peace in the pod file.